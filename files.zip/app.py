import streamlit as st
import pandas as pd
import plotly.express as px
from parser import parse_workbook

st.set_page_config(page_title="Dashboard ตำหนิหลังขัด", layout="wide", page_icon="📊")

st.title("📊 Dashboard สรุปตำหนิหลังขัด")
st.caption("Metro M.D.F. — วิเคราะห์ตำหนิหลังขัดจากรายงานไม้เข้าขัดประจำวัน")

# ---------- Upload & parse ----------
with st.sidebar:
    st.header("📁 อัปโหลดไฟล์")
    uploaded = st.file_uploader("ไฟล์ Excel รายเดือน (.xls)", type=["xls"])
    col_m, col_y = st.columns(2)
    with col_m:
        month = st.number_input("เดือน", min_value=1, max_value=12, value=9)
    with col_y:
        year_be = st.number_input("ปี (พ.ศ.)", min_value=2560, max_value=2600, value=2569)

if uploaded is None:
    st.info("⬅️ อัปโหลดไฟล์ Excel รายเดือน (แยก Sheet ตามวันที่ 1-31) ในแถบด้านซ้ายเพื่อเริ่มต้น")
    st.stop()

with st.spinner("กำลังอ่านไฟล์..."):
    try:
        df = parse_workbook(uploaded.read(), year_be=int(year_be), month=int(month))
    except Exception as e:
        st.error(f"ไม่สามารถอ่านไฟล์ได้: {e}")
        st.stop()

if df.empty:
    st.warning("ไม่พบข้อมูลตำหนิในไฟล์ที่อัปโหลด กรุณาตรวจสอบไฟล์และเดือน/ปีที่เลือก")
    st.stop()

defect_cols = [c for c in df.columns if c.startswith("ตำหนิ::")]

# ---------- Date filter ----------
min_date, max_date = df["date"].min().date(), df["date"].max().date()
st.sidebar.header("📅 เลือกช่วงวันที่")
date_range = st.sidebar.date_input(
    "ช่วงวันที่ที่ต้องการดู",
    value=(min_date, max_date),
    min_value=min_date,
    max_value=max_date,
)
if isinstance(date_range, tuple) and len(date_range) == 2:
    start_date, end_date = date_range
else:
    start_date, end_date = min_date, max_date

mask = (df["date"].dt.date >= start_date) & (df["date"].dt.date <= end_date)
fdf = df[mask].copy()

if fdf.empty:
    st.warning("ไม่มีข้อมูลในช่วงวันที่ที่เลือก")
    st.stop()

def be(d):
    return f"{d.day:02d}/{d.month:02d}/{d.year + 543 - 2000:02d}"

st.caption(f"ช่วงข้อมูลที่แสดง: **{be(start_date if hasattr(start_date,'day') else pd.Timestamp(start_date))} - {be(end_date if hasattr(end_date,'day') else pd.Timestamp(end_date))}** ({fdf['day'].nunique()} วันที่มีข้อมูล)")

# ---------- KPI: % ตำหนิหลังขัด ----------
total_cu = fdf["ยอดไม้เข้าขัด(CU)"].sum()
total_defect = fdf["ตำหนิหลังขัด(คิว)"].sum()
pct_defect = (total_defect / total_cu * 100) if total_cu > 0 else 0

k1, k2, k3 = st.columns(3)
k1.metric("% ตำหนิหลังขัด", f"{pct_defect:.2f} %")
k2.metric("ยอดไม้เข้าขัดทั้งหมด (Cu.)", f"{total_cu:,.2f}")
k3.metric("ตำหนิหลังขัดทั้งหมด (คิว)", f"{total_defect:,.2f}")

st.divider()

# ---------- Top 5 defects ----------
left, right = st.columns([1.1, 1])

with left:
    st.subheader("🔝 Top 5 ตำหนิ (จำนวนแผ่นรวม)")
    defect_sums = fdf[defect_cols].sum().sort_values(ascending=False)
    defect_sums = defect_sums[defect_sums > 0]
    top5 = defect_sums.head(5)
    top5_display = top5.rename(index=lambda x: x.replace("ตำหนิ::", ""))

    if top5_display.empty:
        st.info("ไม่มีข้อมูลตำหนิรายชนิดในช่วงวันที่นี้")
    else:
        fig = px.bar(
            top5_display[::-1],
            orientation="h",
            labels={"value": "จำนวนแผ่น (Pcs)", "index": "ประเภทตำหนิ"},
            text=top5_display[::-1].values,
        )
        fig.update_traces(texttemplate="%{text:,.0f}", textposition="outside")
        fig.update_layout(showlegend=False, height=350, margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig, use_container_width=True)

        top5_table = top5_display.reset_index()
        top5_table.columns = ["ประเภทตำหนิ", "จำนวนแผ่น (Pcs)"]
        top5_table.index = top5_table.index + 1
        st.dataframe(top5_table, use_container_width=True)

# ---------- % ตำหนิแยกตามหัวหน้ากะ ----------
with right:
    st.subheader("👷 % ตำหนิหลังขัด แยกตามหัวหน้ากะ")
    leader_grp = fdf.groupby("หัวหน้ากะ").agg(
        ยอดเข้าขัด_CU=("ยอดไม้เข้าขัด(CU)", "sum"),
        ตำหนิ_คิว=("ตำหนิหลังขัด(คิว)", "sum"),
    )
    leader_grp = leader_grp[leader_grp["ยอดเข้าขัด_CU"] > 0]  # ตัดหัวหน้ากะที่ไม่มียอดเข้าขัด (หารไม่ได้)
    leader_grp["% ตำหนิ"] = (leader_grp["ตำหนิ_คิว"] / leader_grp["ยอดเข้าขัด_CU"] * 100).round(2)
    leader_grp = leader_grp.sort_values("% ตำหนิ", ascending=False)
    leader_grp = leader_grp.rename(columns={
        "ยอดเข้าขัด_CU": "ยอดไม้เข้าขัด (Cu.)",
        "ตำหนิ_คิว": "ตำหนิหลังขัด (คิว)",
    })
    leader_grp = leader_grp.reset_index()
    leader_grp.index = leader_grp.index + 1

    st.dataframe(
        leader_grp.style.format({
            "ยอดไม้เข้าขัด (Cu.)": "{:,.2f}",
            "ตำหนิหลังขัด (คิว)": "{:,.2f}",
            "% ตำหนิ": "{:.2f}%",
        }),
        use_container_width=True,
    )

    fig2 = px.bar(
        leader_grp,
        x="หัวหน้ากะ",
        y="% ตำหนิ",
        text="% ตำหนิ",
    )
    fig2.update_traces(texttemplate="%{text:.2f}%", textposition="outside")
    fig2.update_layout(height=300, margin=dict(l=10, r=10, t=10, b=10))
    st.plotly_chart(fig2, use_container_width=True)

st.divider()
with st.expander("📄 ดูข้อมูลดิบ (หลังกรองตามวันที่)"):
    st.dataframe(fdf.drop(columns=[c for c in defect_cols]), use_container_width=True)
