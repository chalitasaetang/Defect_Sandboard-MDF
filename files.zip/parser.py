"""
Parser for Metro M.D.F. daily sanding defect report (.xls, one sheet per day).

File layout per day-sheet (0-indexed rows/cols):
  Row 10 (col A) == "TH"  -> marks a sheet that HAS a data table (some days have
                              no production, e.g. "ไม่ได้ขัดไม้" -> skip entirely)
  Row 10-12               -> 3-row merged header
  Row 13 onward            -> one row per (wood spec / เครื่องขัด) production line
      col A (0) = TH (thickness)
      col E (4) = หัวหน้ากะ (shift leader name)
      col G (6) = วันผลิต (production date, dd/mm) -- NOT reliable for year/month
      col H (7) = จำนวนที่เข้าขัด (แผ่น)
      col I (8) = ยอดไม้เข้าขัดทั้งหมด (CU.)   <-- denominator for %
      col N (13) = ตำหนิ(คิว) ทั้งหมด            <-- numerator for %
      col Q (17) onward = per-defect-type columns (Pcs), header spans row 11+12
  Row where col G == "Total" -> end of data table

The sheet NAME itself (e.g. "1".."31") is the day-of-month; it is combined with
a user-supplied month/year to build the real date, since the in-sheet date text
is inconsistently placed/formatted across days.
"""

import xlrd
import pandas as pd
import re

TABLE_START_ROW = 13      # 0-indexed; first data row
HEADER_ROWS = (10, 11, 12)
COL_THICKNESS = 0
COL_LEADER = 4
COL_QTY_SHEETS = 7
COL_CU_IN = 8              # ยอดไม้เข้าขัดทั้งหมด (CU.)
COL_DEFECT_TOTAL = 13      # ตำหนิ(คิว) ทั้งหมด
COL_DEFECT_TYPES_START = 17  # right of this = per-defect-type Pcs columns


def _sheet_has_data_table(sheet) -> bool:
    if sheet.nrows <= 10:
        return False
    try:
        return str(sheet.cell_value(10, COL_THICKNESS)).strip() == "TH"
    except IndexError:
        return False


def _build_defect_col_names(sheet) -> dict:
    """Combine header rows 11 and 12 into a readable defect-type name per column."""
    names = {}
    for c in range(COL_DEFECT_TYPES_START, sheet.ncols):
        part1 = str(sheet.cell_value(11, c)).strip()
        part2 = str(sheet.cell_value(12, c)).strip()
        label = (part1 + part2).strip()
        if label:
            names[c] = label
    return names


def _find_total_row(sheet) -> int:
    for r in range(TABLE_START_ROW, sheet.nrows):
        v = sheet.cell_value(r, 6)
        if str(v).strip() == "Total":
            return r
    return sheet.nrows  # no Total marker found; read until end


def parse_workbook(file_bytes, year_be: int, month: int) -> pd.DataFrame:
    """
    Parse the whole monthly .xls workbook into one tidy row-per-production-line
    DataFrame, with a proper `date` column built from (sheet name = day, month, year_be).

    year_be: Buddhist-era year, e.g. 2569
    month: 1-12
    """
    wb = xlrd.open_workbook(file_contents=file_bytes)
    all_rows = []

    for sheet_name in wb.sheet_names():
        if not re.fullmatch(r"\d+", sheet_name.strip()):
            continue  # skip any non-numeric sheet name defensively
        day = int(sheet_name.strip())
        sheet = wb.sheet_by_name(sheet_name)

        if not _sheet_has_data_table(sheet):
            continue

        defect_cols = _build_defect_col_names(sheet)
        total_row = _find_total_row(sheet)

        try:
            date = pd.Timestamp(year=year_be - 543, month=month, day=day)
        except ValueError:
            continue  # e.g. day 31 in a 30-day month -> skip invalid sheet

        for r in range(TABLE_START_ROW, total_row):
            leader = str(sheet.cell_value(r, COL_LEADER)).strip()
            cu_in = sheet.cell_value(r, COL_CU_IN)
            defect_total = sheet.cell_value(r, COL_DEFECT_TOTAL)

            # Skip fully blank / non-data rows (e.g. stray formatting rows)
            if leader == "" and (cu_in in ("", None)):
                continue
            if not isinstance(cu_in, (int, float)):
                continue

            row = {
                "date": date,
                "day": day,
                "หัวหน้ากะ": leader if leader else "(ไม่ระบุ)",
                "ยอดไม้เข้าขัด(CU)": float(cu_in) if cu_in not in ("", None) else 0.0,
                "ตำหนิหลังขัด(คิว)": float(defect_total) if isinstance(defect_total, (int, float)) else 0.0,
            }
            for c, label in defect_cols.items():
                v = sheet.cell_value(r, c)
                row[f"ตำหนิ::{label}"] = float(v) if isinstance(v, (int, float)) else 0.0

            all_rows.append(row)

    if not all_rows:
        return pd.DataFrame()

    df = pd.DataFrame(all_rows)
    return df


def buddhist_year_from_filename_hint(default_be: int = None) -> int:
    return default_be
